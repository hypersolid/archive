import sys,time

time.sleep(16)

open(sys.argv[2]).write(sys.argv[1])