import os
from numpy import *

f=open('params.txt','w')

for HEIGHT in [.4]:
    for LHEIGHT in [.01]:
        for CCENTER in [.1,.15,.2,.25,.3]:
			for AAA in [.09,.06,.03]:
				for SENSOR_OFFSET in [.1]:
					for ACTUATOR in linspace(0.4,1.6,20):
						call = 'HEIGHT=%s LHEIGHT=%s CCENTER=%s AAA=%s SENSOR_OFFSET=%s ACTUATOR=%s'
						call = call%(HEIGHT,LHEIGHT,CCENTER,AAA,SENSOR_OFFSET,ACTUATOR)
						f.write(call+'\n')
f.close()
